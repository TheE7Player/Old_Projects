﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Globalization;

namespace wfc_scrapper
{
    class Program
    {

        #region Variables
        /// <summary>
        /// Data class which holds film data
        /// </summary>
        public struct Film
        {
            /// <summary>
            /// Holds the film title
            /// </summary>
            public string Title;

            /// <summary>
            /// Holds the Films Certificate (UK Standard: PG, 12, 15 etc)
            /// </summary>
            public string Certificate;

            /// <summary>
            /// Holds the URL of the cover of the film
            /// </summary>
            public string Covert_URL;

            /// <summary>
            /// Holds the films description
            /// </summary>
            public string Description;

            /// <summary>
            /// Holds the times (dd/mm/yyyy format), and each times showings
            /// </summary>
            public Dictionary<string, string[]> Showings;
        }

        /// <summary>
        /// A Dictionary which has values based on short month (turns it into number: Jan = 1 etc)
        /// </summary>
        private static Dictionary<string, int> GetMonthDate = new Dictionary<string, int>()
        {
            { "Jan", 1 },
            { "Feb", 2 },
            { "Mar", 3 },
            { "Apr", 4 },
            { "May", 5 },
            { "Jun", 6 },
            { "Jul", 7 },
            { "Aug", 8 },
            { "Sep", 9 },
            { "Oct", 10 },
            { "Nov", 11 },
            { "Dec", 12 }
        };

        #endregion

        private static void Main(string[] args)
        {
            GetHTML();
            Console.ReadLine();
        }

        private static void GetHTML()
        {
            //Holds the site we want to extract data from
            var link = "https://waterfrontcinema.savoysystems.co.uk/WaterfrontCinema.dll/";

            var client = new HttpClient();
            string responce = String.Empty;

            try
            {
                //Have to call it this way due to the website using UTF-8 Formatting (HtmlAgilityPack hates that format!)
                using (HttpResponseMessage response = client.GetAsync(link).Result)
                {
                    var byteArray = response.Content.ReadAsByteArrayAsync().Result;
                    responce = Encoding.UTF8.GetString(byteArray, 0, byteArray.Length);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }

            var doc = new HtmlDocument();
            doc.LoadHtml(responce);

            //Get the films from the website under div class(es) "programme" and "twelvecol"
            var movie_list = GetElements(doc, "div", "class", "programme twelvecol");

            //Great now we got the list of current running films with their information!
            //We'll store them under "list_of_films"!
            var list_of_films = new List<Film>(movie_list.Count);

            //Time to do a loopty-loop! WEEEEEEEEEEEEEEE ...
            foreach (var film in movie_list)
            {
                //Item1: Name, Item2: Rating
                var name_and_rating = GetNameAndRating(film);
                string cover_link = GetCover(film);
                string movie_desc = GetDescription(film);
                var times = GetTimes(film);
                list_of_films.Add(new Film
                {
                    Title = name_and_rating.Item1,
                    Certificate = name_and_rating.Item2,
                    Covert_URL = cover_link,
                    Description = movie_desc,
                    Showings = times
                });
            }

            Console.WriteLine("Films extracted from Waterfront Cinema Website");
            //For testing and making sure it works *such fun*, let's print it out:
            foreach (var item in list_of_films)
            {              
                Console.WriteLine($"├── {item.Title} ({item.Certificate})");
                Console.WriteLine($"|   └── Description: {item.Description} ");
                foreach (var dates in item.Showings)
                {
                    string[] fix_date = dates.Key.Split('-');

                    if (fix_date[0].Length != 2)
                        fix_date[0] = $"0{fix_date[0]}";

                    if (fix_date[1].Length != 2)
                        fix_date[1] = $"0{fix_date[1]}";

                    string fixed_date = string.Join("-", fix_date);
                    DateTime dt = DateTime.ParseExact(fixed_date, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                    fixed_date = null;
                    fix_date = null;

                    /*
                        DateTime.ToString() format:
                        d -> Get the date (dd to get the 0 in front)
                            Date: 4
                            └── With just "d": 4
                            └── With "dd": 04

                        dddd -> Get day of the week (Monday, Tuesday etc)
                                
                        MMM -> Get the month in short form
                               Month: January
                               └── With just "MMM": Jan
                               └── With "MMMM": January

                        yyyy -> Get year format (2019, 2020, 2021 etc)                     
                    */

                    Console.WriteLine($"|   └── Showings for: {dt.ToString("d dddd MMM yyyy")}:".Trim());
                    for (int i = 0; i < dates.Value.Length; i++)
                    {
                        Console.WriteLine($"|       └── Show {i + 1} at {dates.Value[i]}");
                    }

                }
            }

            Console.ReadLine();
        }

        #region Custom Helper Functions
        private static List<HtmlNode> GetElements(HtmlDocument target, string parent_element, string element_type, string element_name)
        {
            return target.DocumentNode.Descendants(parent_element)
                .Where(node => node.GetAttributeValue(element_type, string.Empty)
                .Equals(element_name)).ToList();
        }

        private static List<HtmlNode> GetElements(HtmlNode target, string parent_element, string element_type, string element_name)
        {
            return target.Descendants(parent_element)
                .Where(node => node.GetAttributeValue(element_type, string.Empty)
                .Equals(element_name)).ToList();
        }

        private static HtmlNode GetElementChildren(HtmlNode parent, string element_target)
        {
            return parent.Descendants(element_target).FirstOrDefault();
        }

        private static List<HtmlNode> GetElementChildrens(HtmlNode parent, string element_target)
        {
            return parent.Descendants(element_target).ToList();
        }

        private static HtmlNode GetElement(HtmlNode parent, string parent_element, string element_type, string element_name)
        {
            try
            {
                return parent.Descendants(parent_element)
                .Where(node => node.GetAttributeValue(element_type, string.Empty)
                .Equals(element_name)).FirstOrDefault();
            }
            catch (Exception)
            {
                return null;
            }
        }

        private static string GetElementText(HtmlNode parent, string parent_element, string default_value = "")
        {
            try
            {
                return parent.Descendants(parent_element).FirstOrDefault().InnerText;
            }
            catch (Exception)
            {
                if (String.IsNullOrEmpty(default_value))
                    return string.Empty;
                else
                    return default_value;
            }
        }

        private static string GetAttributeValue(HtmlNode parent, string child_target, string attribute_name, string default_value = "")
        {
            try
            {
                var target = parent.ChildNodes
                    .Where(x => x.Name == child_target)
                    .FirstOrDefault();

                var result = target.Attributes[attribute_name].Value;

                if (String.IsNullOrEmpty(result))
                    throw new Exception(); //Force it to throw itself, for a laugh...

                return result;
            }
            catch (Exception)
            {
                if (String.IsNullOrEmpty(default_value))
                    return string.Empty;
                else
                    return default_value;
            }
        }

        #endregion

        #region Web-Scrapping Functions
        private static Tuple<string, string> GetNameAndRating(HtmlNode link)
        {
            var movie_title = link.Descendants("h1").FirstOrDefault().InnerText; // <- Tell it to target the h1 tag

            //Get the location in the string where (is)
            int cert_index = movie_title.IndexOf('(');

            //Now substring "movie_title" to extract the certificate - this excludes the ( and ) initially, so we get the text itself
            var cert = movie_title.Substring(cert_index + 1, (movie_title.IndexOf(')') - 1) - cert_index);

            //Since we've got the age rating of the film - we can now modify the variable that holds it!
            movie_title = movie_title.Substring(0, cert_index - 1);

            return Tuple.Create(movie_title, cert);
        }

        private static string GetCover(HtmlNode link)
        {        
            HtmlNode image = GetElement(link, "div", "class", "twocol image");

            string img_str = GetAttributeValue(image, "img", "src", "No Image Found");

            return img_str;
        }

        private static string GetDescription(HtmlNode link)
        {

            var inner_div = GetElement(link, "div", "class", "tencol synopsis hide-for-small last");

            var target = GetElementText(inner_div, "p", "None");

            return target;
        }

        private static Dictionary<string, string[]> GetTimes(HtmlNode link)
        {
            // This fetches all the children from element "<table>" which holds the date and available times
            var times_list = GetElement(link, "div", "class", "twelvecol showtimes"); 

            // This control holds a key and value (With initial size set to how many table elements are returned): 
            //      Key: The date which holds all the available times (Thursday 2 Jan 2020)
            //      Value: An array of available times on that date of showing (13:45, 17:00, 19:40)
            
            var target = GetElementChildren(times_list, "table");

            //Now we target the tables that are avaialble
            var dates = target.Descendants("tr").Skip(1);

            var time_dict = new Dictionary<string, string[]>(dates.Count<HtmlNode>());

            string regexPattern = @"(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\s([0-9]|[1-3][0-9])\s(.+)\s(\d{4})(\d{2}:\d{2})?(\d{2}:\d{2})?(\d{2}:\d{2})?";
            Regex regex = new Regex(regexPattern);

            /*
               Match Groups in Regex (8 Matches):
               [0]: Raw Input (Input to look at)
               [1]: Day (Mon, Tue, Wed)
               [2]: Date (Just number, no: st, rd, nd etc)
               [3]: Month (Substringed to 3 letters: January = Jan)
               [4]: Year (Full format: 2020, 2021 etc)
               [5]: First showing time
               [6]: Second showing time (If any)
               [7]: Third showing time (If any)
            */

            foreach (HtmlNode item in dates)
            {
                var m = Regex.Match(item.InnerText, regexPattern);

                if (m.Success)
                {
                    //Remember: There are 7 available match groups!
                    bool All_3_Viewings = (m.Groups[5].Success && m.Groups[6].Success && m.Groups[7].Success);

                    if(All_3_Viewings)
                    {
                        string _date = $"{m.Groups[2].Value}-{GetMonthDate[m.Groups[3].Value]}-{m.Groups[4].Value}";

                        string[] times = new string[]{ m.Groups[5].Value, m.Groups[6].Value, m.Groups[7].Value };

                        time_dict.Add(_date, times);
                    }
                    else
                    {

                        int available_showings = GetGroupTimeCount(m.Groups[5], m.Groups[6], m.Groups[7]);
                        string _date = $"{m.Groups[2].Value}-{GetMonthDate[m.Groups[3].Value]}-{m.Groups[4].Value}";
                        List<string> times = new List<string>();

                        if(available_showings >= 1)
                            times.Add(m.Groups[5].Value);

                        if (available_showings >= 2)
                            times.Add(m.Groups[6].Value);

                        if (available_showings >= 3)
                            times.Add(m.Groups[7].Value);

                        time_dict.Add(_date, times.ToArray());
                    }

                }
                else
                {
                    Console.WriteLine($"Failed to parse valid date w/ regex pattern! ({item.InnerText})");
                }
            }

            return time_dict;
        }

        private static int GetGroupTimeCount(params Group[] group)
        {
            int successcount = 0;
            foreach (var item in group)
            {
                if (item.Success)
                    successcount++;
            }
            return successcount;
        }

        #endregion
    }
}
