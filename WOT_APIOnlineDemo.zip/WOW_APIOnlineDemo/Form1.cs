﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Text.RegularExpressions; //<- Allows us to use the Regex Class
using System.Net;
using System.Threading;

namespace WOW_APIOnlineDemo
{
    public partial class Form1 : Form
    {
        //Raw Regex Pattern -> \"players_online\":(\d+),\"server\":\"(RU\d+)\"

        //Note: \d will be \\d as \ in a string is not allowed (No escape characters allowed in Strings)
        private const string regex = "\"players_online\":(\\d+),\"server\":\"(RU\\d+)\"}";

        private int UpdateFrequency = 1000; //in ms
        private int UpdateOffest = 1000;
        private int ServerUpdates = 0;

        public static Dictionary<string, List<string>> ServerPlayerCountHistory = new Dictionary<string, List<string>>(1);

        private bool ControlsCreated = false;

        public static event EventHandler APIUpdateInvoked;

        public Form1()
        {
            InitializeComponent();
        }

        private void UpdateControls()
        {
            ServerUpdates = 0;

            var GetResponce = GetAPI();

            if (GetResponce == null) return;

            var SortedServerList = GetResponce.Keys.Select(x => Convert.ToInt32(x.Substring(2))).ToList();
            SortedServerList.Sort(); //Sort the array

            for (int i = 0; i < SortedServerList.Count; i++)
            {

                //Display back the servers in ascending order, RU1 to RU11 etc
                if (!ControlsCreated)
                {
                    MakeNewPanel($"RU{SortedServerList[i]}", $"{GetResponce[String.Format("RU{0}", SortedServerList[i])]}");
                    ServerPlayerCountHistory.Add(String.Format("RU{0}", SortedServerList[i]), new List<string>());
                    ServerPlayerCountHistory[String.Format("RU{0}", SortedServerList[i])].Add($"{DateTime.Now.ToString("HH:mm")}-{GetResponce[String.Format("RU{0}", SortedServerList[i])]}");
                }
                else
                {
                    string KeyName = String.Format("RU{0}", SortedServerList[i]);
                    string ValueInput = $"{DateTime.Now.ToString("HH:mm")}-{GetResponce[String.Format("RU{0}", SortedServerList[i])]}";
                    string LastInput = ServerPlayerCountHistory[KeyName][ServerPlayerCountHistory[KeyName].Count - 1];
                    if (LastInput.Substring(LastInput.IndexOf('-')) != ValueInput.Substring(ValueInput.IndexOf('-')))
                    {
                        //Console.WriteLine($"UPDATING {KeyName} with {ValueInput}");
                        ServerPlayerCountHistory[KeyName].Add(ValueInput);

                        flowLayoutPanel1.Controls[i].Invoke(new Action(() => 
                        {
                            foreach (Control p in flowLayoutPanel1.Controls[i].Controls)
                            {
                                if (p is Label && p.Name == "CurrentPlayersText")
                                {
                                    ServerUpdates++;
                                    string LastText = p.Text;
                                    p.Text = $"Current Players: {GetResponce[String.Format("RU{0}", SortedServerList[i])]}"; ;

                                    if (p.Text != LastText) { p.ForeColor = Color.Green; } else { p.ForeColor = Color.Black; }
                                }
                            }
                        }));
                    }

                }
            }

            //Invoke any method that is subscribed to this event
            if (APIUpdateInvoked != null)
                APIUpdateInvoked.Invoke(this, EventArgs.Empty);

            //Acts like a switch!
            if (!ControlsCreated) { ControlsCreated = true; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateControls();
            backgroundWorker1.RunWorkerAsync();
        }

        private void MakeNewPanel(string ServerName, string CurrentOnline)
        {
            #region Controls Setup
                Panel panelMain = new Panel();
                Label ServerTitle = new Label(), CurrentPlayers = new Label();
                Button button = new Button();
                string serverNumber = ServerName.Substring(2);
            #endregion

            #region Server Title Label GUI Setup
                ServerTitle.AutoSize = true;
                ServerTitle.Location = new System.Drawing.Point(18, 11);
                ServerTitle.Name = "ServerText";
                ServerTitle.Size = new System.Drawing.Size(47, 13);
                ServerTitle.TabIndex = 0;
                ServerTitle.Text = $"Server {serverNumber}";
            #endregion
            
            #region Current Players Label GUI Setup
                CurrentPlayers.AutoSize = true;
                CurrentPlayers.Location = new System.Drawing.Point(18, 35);
                CurrentPlayers.Name = "CurrentPlayersText";
                CurrentPlayers.Size = new System.Drawing.Size(90, 13);
                CurrentPlayers.TabIndex = 1;
                CurrentPlayers.Text = $"Current Players: {CurrentOnline}";
            #endregion

            #region Button Control GUI Setup
            button.AutoSize = true;
            button.Location = new System.Drawing.Point(18, 50);
            button.Size = new System.Drawing.Size(90, 13);
            button.TabIndex = 3;
            button.Text = $"View Stats";
            button.Click += (o, i) =>
            {
                ServerInformation nw = new ServerInformation(ServerName);
                nw.ShowDialog();
                nw.Dispose();
                nw = null;
            };

            #endregion

            #region Panel GUI Code
            panelMain.Controls.Add(ServerTitle);
                panelMain.Controls.Add(CurrentPlayers);
                panelMain.Controls.Add(button);
                panelMain.Location = new System.Drawing.Point(3, 3);
                panelMain.Name = $"groupControl{serverNumber}";
                panelMain.Size = new System.Drawing.Size(200, 100);
                panelMain.TabIndex = 2;
            #endregion

            //Add our new panel onto the flowLayoutPlanel1
            flowLayoutPanel1.Controls.Add(panelMain);

            #region GC Control
                //Tell GC to get rid of these controls as we appened them already in GUI
                panelMain = null;
                ServerTitle = null;
                CurrentPlayers = null;
                serverNumber = null;
                button = null;
            #endregion
        }

        private SortedDictionary<string, int> GetAPI()
        {
            Regex pattern = new Regex(regex);
            WebClient webClient = null;
            string result = String.Empty; //String.Empty is better, doesn't create object (As "" does!)

            try
            {
                using (webClient = new WebClient())
                {
                    //Put the responce from the API into result
                    result = webClient.DownloadString("https://api.worldoftanks.ru/wgn/servers/info/?application_id=820afebf6a07a0b916abcf89c832277c&game=wot&language=ru");
                } //<- Once This line is hit, webClient automatically calls webClient.Dispose(); (Or trys to)

                //Now, we run it through Regex
                MatchCollection matches = pattern.Matches(result);
                if (Object.Equals(matches, null)) { MessageBox.Show("NO MATCHES FOUND IN REGEX!"); return null; }

                SortedDictionary<string, int> ReturnResult = new SortedDictionary<string, int>();

                for (int i = 0; i < matches.Count; i++)
                {
                    GroupCollection groups = matches[i].Groups;
                    // Group[0] = Full string, Group[1] = Number of players, Group[2] = Server name

                    int Number = 0;
                    int.TryParse(groups[1].Value, out Number);

                    ReturnResult.Add(groups[2].Value, Number);
                   // Console.WriteLine($"Server \"{groups[2]}\" has: {groups[1]} players currently playing!");
                }

                return ReturnResult;
            }
            catch (Exception e)
            {
                MessageBox.Show($"EXPECTION:\r\n{e.Message}");
                return null;
            }
            finally
            {
                //Clean up webClient after usage (GOOD PRACTICE)
                if(!Object.Equals(webClient, null))
                {
                    //This means that webClient hasn't be cleared, so we'll manually tell it to
                    webClient.Dispose();
                }
                result = null; //Tell GC we're finished with this string (String(s) take up alot of memory!)
            }
        }

        private void BackgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {

                Thread.Sleep(UpdateFrequency + UpdateOffest);
                this.statusStrip1.Invoke(new Action (() => toolStripStatusLabel1.Text = "Status: Fetching information from API"));
                //toolStripStatusLabel1.Text = "Status: Fetching information from API";

                Thread.Sleep(UpdateFrequency);
                UpdateControls();
                this.statusStrip1.Invoke(new Action(() => toolStripStatusLabel1.Text = (ServerUpdates == 0) ? "Status: No server updates, Same volume of players in server" : $"Status: {ServerUpdates} updates within 12 servers!"));
                //toolStripStatusLabel1.Text = "Status: Updated information on each control!";

                Thread.Sleep(UpdateFrequency + UpdateOffest);
                this.statusStrip1.Invoke(new Action(() => toolStripStatusLabel1.Text = "Status: Waiting for next information cycle..."));
                //toolStripStatusLabel1.Text = "Status: Waiting for next information cycle...";

            }
        }
    }
}
