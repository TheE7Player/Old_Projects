﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WOW_APIOnlineDemo
{
    public partial class ServerInformation : Form
    {
        private string serverReference = String.Empty;
        private double MaxHeight = 0;
        private int GraphMinOffset = 200;

        private int lastCount = -1;

        public ServerInformation(String name)
        {
            serverReference = name;
            InitializeComponent();        
        }

        private void Chart1_Click(object sender, EventArgs e)
        {
            UpdateChart();
        }

        private void UpdateChart()
        {
                var list = Form1.ServerPlayerCountHistory[serverReference];

                if (lastCount == -1)
                    lastCount = list.Count();
                else
                    if (list.Count() == lastCount)
                        return;

                if (chart1.Series["Players"].Points.Count > 0)
                    chart1.Invoke(new Action(() => {
                        chart1.Series["Players"].Points.Clear();
                    }));

                listBox1.Invoke(new Action(() => { listBox1.Items.Clear(); }));

                var ServerPlayers = Convert.ToDouble(list.Select(i => i.Split('-')[1]).Max());

                if (MaxHeight == 0)
                    MaxHeight = ServerPlayers;
                else
                    if(MaxHeight < ServerPlayers)
                        MaxHeight = ServerPlayers;

                chart1.Invoke(new Action(() => 
                {
                    chart1.ChartAreas[0].AxisY.Maximum = MaxHeight + GraphMinOffset;
                    chart1.ChartAreas[0].AxisY.Minimum = MaxHeight - GraphMinOffset * 2;
                }));

                foreach (var ix in list)
                {
                    //23:43-14849
                    try
                    {
                        string[] r = ix.Split('-');
                    
                        chart1.Invoke(new Action(() => { chart1.Series["Players"].Points.AddXY(r[0], Convert.ToInt32(r[1])); }));
                        
                    }
                    catch(InvalidOperationException e)
                    {
                         Console.WriteLine(e.Message);
                    }

                }

                listBox1.Invoke(new Action(() =>
                {
                    int lastNum = -1;
                    string[] x;
                    for (int i = 0; i < list.Count; i++)
                    {
                        x = list[i].Split('-');
                        if (lastNum == -1)
                        {
                            lastNum = Convert.ToInt32(x[1]);
                            listBox1.Items.Add($"[{serverReference}] At {x[0]}, Player count was {x[1]}");
                        }
                        else
                        {
                            int NewNum = Convert.ToInt32(x[1]);
                            if (NewNum > lastNum)
                            {                               
                                listBox1.Items.Add($"[{serverReference}] At {x[0]}, Player count was {x[1]} (+{NewNum - lastNum})");
                                lastNum = NewNum;
                            }
                            else
                            {
                                listBox1.Items.Add($"[{serverReference}] At {x[0]}, Player count was {x[1]} (-{lastNum - NewNum})");
                                lastNum = NewNum;
                            }
                        }


                    }
                }));

            label1.Invoke(new Action(() => { label1.Text = $"Last API GUI Update: {DateTime.Now.ToString("HH:mm.ss")}"; }));
        }

        private void APICalled(object sender, EventArgs e)
        {
            //Console.Beep(); <- For testing purposes
            UpdateChart();
        }

        private void ServerInformation_Load(object sender, EventArgs e)
        {
            //Subscribe to the event so we can update our graph are certain intervals!
            Form1.APIUpdateInvoked += APICalled;
            UpdateChart();    
        }

        private void ServerInformation_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Unsubscribe to the event as we don't need it anymore!
            Form1.APIUpdateInvoked -= APICalled;
        }
    }
}
