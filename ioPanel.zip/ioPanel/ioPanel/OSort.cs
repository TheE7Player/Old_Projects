﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.Generic;
namespace ioPanel
{
    public partial class OSort : Form
    {


        public delegate void EventHandler();
        public static event EventHandler OnEventClose;

        private static List<string> catg = new List<string>();
        private static List<Tuple<string, string>> Paymentcategories = new List<Tuple<string, string>>();

        #region Functions

        public class cOut
        {
            public string CatName { get; set; }
            public string lOfPayName { get; set; }
        }

        /// <summary>
        /// Grabs all the categories with their type and name
        /// </summary>
        /// <returns></returns>
        public static string CateOutPut()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendLine("{");
            for (int i = 0; i < Paymentcategories.Count; i++)
            {
                builder.AppendLine($"[{Paymentcategories[i].Item1.ToString()}->{Paymentcategories[i].Item2.ToString()}]");
            }            
            builder.AppendLine("}");
            return builder.ToString();
        }

        public static void InputCat(string[] Category)
        {
            //Grabing entitys with only "->"
            var ValiadEntity = Category.Where(x => x.Contains("->")).ToArray();

            for (int i = 0; i < ValiadEntity.Length; i++)
            {
                var InterestString = ValiadEntity[i];
                var Entity = InterestString.Replace("[","").Replace("]", "").Trim().Replace("->", "`").Split('`');

                //Entity[0] = cat, Entity[1] = payment.

                //First we summit the cat
                if(!catg.Contains(Entity[i])) //Checking if it doesn't exist already
                     catg.Add(Entity[i]);

                //Now we summit the Tuple (Variable that connects Cateogry to Payment
                Paymentcategories.Add(new Tuple<string, string>(Entity[0], Entity[1]));

            }

           
        }

        private static int GetTupleLength(dynamic tuple)
        {
            var aType = tuple.GetType();
            return aType.GetGenericArguments().Length;
        }

        /// <summary>
        /// Grabs a list of payments based on what category is searched for
        /// </summary>
        /// <param name="Cat">The category you want to see payments for</param>
        /// <returns></returns>
        public static List<Transaction> GetPaymentsFromCategory(string Cat)
        {
            var Item = new List<Transaction>();

            for (int i = 0; i < Paymentcategories.Count; i++)
            {
                if(Paymentcategories[i].Item1.ToString() == Cat)
                {
                    Item.Add(new Transaction(Money.GetTransactionInfo(Paymentcategories[i].Item2.ToString())));
                }

            }
            return Item;
        }

        public static List<string> GetCag()
        {
            var Item = new List<string>();

            for (int i = 0; i < Paymentcategories.Count; i++)
            {
                if (!Item.Contains(Paymentcategories[i].Item1.ToString()))
                    Item.Add(Paymentcategories[i].Item1.ToString());
            }
            return Item;
        }
        #endregion


        public OSort()
        {
            InitializeComponent();
        }
       
        private void OSort_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < catg.Count; i++)
            {
                listBox1.Items.Add(catg[i]);
            }
            var pItem = Money.GetPaymentNames();
            for (int z = 0; z < Money.ListAmount(); z++)
            {
                listBox2.Items.Add(pItem[z]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                if(!catg.Contains(textBox1.Text))
                {
                    catg.Add(textBox1.Text.Trim());
                    listBox1.Items.Add(textBox1.Text.Trim());
                    textBox1.Text = "";
                }
                else
                {
                    MessageBox.Show($"{textBox1.Text.Trim()} is already in category's. No action performed");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (catg.Count > 0)
            {
                DialogResult dr = MessageBox.Show("Reseting cat will reset everything that has been stored for it. \r\nYour payments will still be accessable, but it's assigned catagory will be empty.", "Comfirm action", MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    listBox1.Items.Clear();
                    catg.Clear();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("No Cat was selected");
            }
            else
            { 
                if(listBox2.SelectedIndex == -1)
                {
                    MessageBox.Show("No Payment was selected to add to that catg");
                }
                else
                {
                    //This means that the two listboxes have a item selected

                    
                    if (Paymentcategories.Any(m => m.Item2 == listBox2.SelectedItem.ToString()))
                    {
                        var FoundTuple = FindTuple(listBox2.SelectedItem.ToString());
                        
                        if(listBox1.SelectedItem.ToString() == FoundTuple)
                        {
                            MessageBox.Show($"Payment {listBox2.SelectedItem.ToString()} is already associated with {listBox1.SelectedItem.ToString()}. No action was performed.");
                        }
                        else
                        {
                            DialogResult drz = MessageBox.Show($"Payment {listBox2.SelectedItem.ToString()} is assigned to {listBox1.SelectedItem.ToString()} orginally. \r\nOverwrite?", "Comfirm action", MessageBoxButtons.YesNo);
                            if (drz == DialogResult.Yes)
                            {
                                //https://stackoverflow.com/questions/26189007/edit-a-listtuple-item
                                var tuple = Paymentcategories.Find(s => s.Item2 == listBox2.SelectedItem.ToString());
                                Paymentcategories[FindTupleIndex(tuple.Item2)] = new Tuple<string, string>(listBox1.SelectedItem.ToString(), tuple.Item2);
                            }
                        }
                    }
                    else
                    {
                        DialogResult dr = MessageBox.Show($"Payment {listBox2.SelectedItem.ToString()} is about to be associated with {listBox1.SelectedItem.ToString()}. \r\nConfirm action?", "Comfirm action", MessageBoxButtons.YesNo);
                        if (dr == DialogResult.Yes)
                        {
                            Paymentcategories.Add(new Tuple<string, string>(listBox1.SelectedItem.ToString(), listBox2.SelectedItem.ToString()));
                        }
                    }
                }
            }

            int FindTupleIndex(string FindPayment)
            {
                for (int i = 0; i < Paymentcategories.Count; i++)
                {
                    if (Paymentcategories[i].Item2.ToString() == FindPayment)
                    {
                        return i;
                        break;
                    }
                }
                return -1;
            }

            string FindTuple(string FindPayment)
            {
                for (int i = 0; i < Paymentcategories.Count; i++)
                {
                    if (Paymentcategories[i].Item2.ToString() == FindPayment)
                    {
                        return Paymentcategories[i].Item1.ToString();
                        break;
                    }
                }
                return string.Empty;
            }
        }

        private void OSort_FormClosing(object sender, FormClosingEventArgs e)
        {
            //This executes the event so the main form can update.
            OnEventClose.Invoke();
        }
    }
}
