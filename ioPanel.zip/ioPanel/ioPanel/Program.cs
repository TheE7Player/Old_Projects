﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ioPanel
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static Form1 MainForm;
        [STAThread]
        
        static void Main()
        {
            MainForm = new Form1();
            Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            MainForm.ShowDialog();
        }
    }
}
