﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ioPanel
{
    public partial class PaymentBox : UserControl
    {
        public int thisControlIndex;
        private static string tType { get; set; }
        private static decimal Amount { get; set; }
        private static string tName { get; set; }
        private static bool tImport { get; set; }
        public string tDate { get; set; }
        public List<string> tHistory { get; set; }
        public PaymentBox(string traType, decimal amount, string traName, bool tImp, string date)
        {
            tType = traType;
            Amount = amount;
            tName = traName;
            tImport = tImp;
            tDate = date;
            InitializeComponent();
            this.Name = "C" + thisControlIndex;
            //Control header
            label1.Text = traName;
            label3.Text = tDate;
            //Delete star icon if it's not important
            if (!tImp) this.Controls.Remove(pictureBox2);

            if(traType == "+")
            {
                label2.Text = $"£{amount}";
                label2.ForeColor = Color.Green;
            }
            else
            {
                label2.Text = $"£{amount}";
                label2.ForeColor = Color.Red;
            }

            label3.Location = new Point(label2.Right + 15, label3.Location.Y);

            thisControlIndex = Program.MainForm.flowLayoutPanel1.Controls.Count;
        }

        private void PaymentBox_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var EditWindow = new Payment(thisControlIndex);
            EditWindow.ShowDialog();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            var hWin = new History(thisControlIndex);
            hWin.Show();
        }
    }
}
