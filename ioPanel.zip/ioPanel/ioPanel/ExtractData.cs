﻿using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Windows.Forms;

namespace ioPanel
{
    class ExtractData
    {
        public class extRelationShip
        {
            public extRelationShip()
            {
                paymentsName = new List<string>();
            }
            /// <summary>
            /// Used to declear cat.
            /// </summary>
            /// <param name="Name">Name of category</param>
            /// <param name="pMents">Payments names from the Category</param>
            public extRelationShip(string Name, List<string> pMents)
            {
                Cat = Name;
                paymentsName = pMents;
            }

            public string Cat { get; set; }
            public List<string> paymentsName { get; set; }
        }

        //Variable used to gather the payment. Saved to payment.pmInfo
        private static StringBuilder paymentString = new StringBuilder();

        //Variable used to gather categorys. Saved to cateogry.coInfo
        private static string CatString;

        /// <summary>
        /// Appends payments to extraction File
        /// </summary>
        /// <param name="lp">Payment method to be used for appending</param>
        public static void AppendPayments(Transaction lp)
        {
            paymentString.AppendLine($"Type:{lp.tType}` Amount:{lp.Amount.ToString()}`Name:{lp.tName}`Important:{lp.tImport}`DT:{lp.tDate}`M:{GetHistory(lp)}");
        }

        public static void AppendCategorys()
        {
            CatString = OSort.CateOutPut();
        }

        private static string GetHistory(Transaction lp)
        {
            string Result = string.Empty;

            if (lp.tHistory.Count == 0)
                return Result;
            else
            {
                StringBuilder builder = new StringBuilder();
                builder.Append("{");
                for (int i = 0; i < lp.tHistory.Count; i++)
                {
                    builder.Append($"[{lp.tHistory[i]}]");
                }
                builder.Append("}");
                Result = builder.ToString();
            }

            return Result;
        }


        public static void WritetoFile()
        {
            //https://stackoverflow.com/questions/2454956/create-normal-zip-file-programmatically
            byte[] buffer = Encoding.ASCII.GetBytes(paymentString.ToString());
            byte[] buffer2 = Encoding.ASCII.GetBytes(CatString.ToString());

            string saveLoc = string.Empty;

            using (SaveFileDialog saveFileDialog1 = new SaveFileDialog())
            {
                saveFileDialog1.InitialDirectory = @"C:\";
                saveFileDialog1.Title = "Where to save the payments";
                //saveFileDialog1.CheckFileExists = true;
                saveFileDialog1.CheckPathExists = true;
                saveFileDialog1.DefaultExt = "iop";
                saveFileDialog1.Filter = "ioPanel File (*.iop)|*.iop";
                saveFileDialog1.FilterIndex = 2;
                saveFileDialog1.RestoreDirectory = true;
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    saveLoc = saveFileDialog1.FileName;
                }
            }
            using (var fileStream = new FileStream($@"{saveLoc}", FileMode.CreateNew))
            {
                using (var archive = new ZipArchive(fileStream, ZipArchiveMode.Create, true))
                {

                    //Creates the Payment File
                    var zipArchiveEntry = archive.CreateEntry("payment.pmInfo", CompressionLevel.Fastest);
                    using (var zipStream = zipArchiveEntry.Open())
                    {
                        zipStream.Write(buffer, 0, buffer.Length);
                    }

                    //Creates the Category File
                    var zipArchiveEntry2 = archive.CreateEntry("cateogry.coInfo", CompressionLevel.Fastest);
                    using (var zipStream = zipArchiveEntry2.Open())
                    {
                        zipStream.Write(buffer2, 0, buffer2.Length);
                    }
                }
            }

            //Now we clear it for next time use
            paymentString.Clear();
            CatString = paymentString.ToString();
        }


        public static void ZipThing(string Path)
        {
            //https://mytecharea.wordpress.com/2017/07/08/read-the-content-of-a-file-in-a-zip-file-without-extracting-the-file-in-c/

            using (var zipStream = new FileStream($@"{Path}", FileMode.Open))
            using (var archive = new ZipArchive(zipStream, ZipArchiveMode.Read))
            {
                foreach (var entry in archive.Entries)
                {
                    using (var stream = entry.Open())
                    using (var reader = new StreamReader(stream))
                    {
                        if(entry.FullName == "payment.pmInfo")
                        {
                            string line;
                            var list = new List<string>();
                            while ((line = reader.ReadLine()) != null)
                            {
                                list.Add(line);
                            }

                            Money.InsertPayments(list.ToArray());
                        }
                        else
                        {
                            if(entry.FullName == "cateogry.coInfo")
                            {
                                string line;
                                var list = new List<string>();
                                while ((line = reader.ReadLine()) != null)
                                {
                                    list.Add(line);
                                }
                               OSort.InputCat(list.ToArray());
                            }
                        }
                        
                    }
                }
            }
        }
    }
    
}
