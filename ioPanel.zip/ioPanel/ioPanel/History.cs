﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ioPanel
{
    public partial class History : Form
    {
        public History(int index)
        {
            InitializeComponent();

            for (int i = 0; i < Money.ListAmount(); i++)
            {
                if(i == index)
                {
                    var hHist = Money.GetHistory(index);
                    for (int q = 0; q < Money.GetHistory(index).Count; q++)
                    {
                        var Items = hHist[q].Split(',');

                        dataGridView1.Rows.Add(Items[0], Items[1]);
                        dataGridView1.Update();
                        dataGridView1.Refresh();
                    }


                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
