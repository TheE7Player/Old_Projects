﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ioPanel
{
    public partial class Form1 : Form
    {
        public int LastControlBottom = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateText();
            OSort.OnEventClose += new OSort.EventHandler(UpdateCatagoryBox);
            Money.TransactionCompleted += new Money.EventHandler(UpdateText);

            //Automatically selects the first checkbox
            checkedListBox1.SetItemCheckState(0, CheckState.Checked);
        }

        private void UpdateCatagoryBox()
        {
            //Fetechs all categorys
            var Items = OSort.GetCag();
            for (int i = 0; i < Items.Count; i++)
            {
                if (!checkedListBox1.Items.Contains(Items[i]))
                    checkedListBox1.Items.Add(Items[i]);
            }
        }

        private void UpdateText()
        {
            label2.Text = Money.GetBalance(); //Gives string of current balance
            if (Money.GetBalanceNumber() > 0)
            {
                label2.ForeColor = Color.Green;
            }
            else if (Money.GetBalanceNumber() < 0)
            {
                label2.ForeColor = Color.Red;
            }
            else
            {
                label2.ForeColor = Color.Black;
            }
            label2.Update();
            label2.Refresh();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Shows the payment window
            var NewForm = new Payment();
            NewForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var nc = new OSort();
            nc.ShowDialog();
        }

        private void ShowAll()
        {
            flowLayoutPanel1.Controls.Clear();
            for (int i = 0; i < Money.ListAmount(); i++)
            {
                var ItemsToAdd = Money.GetTransactionFromIndex(i);
                var NewPanel = new PaymentBox(ItemsToAdd.tType, ItemsToAdd.Amount, ItemsToAdd.tName, ItemsToAdd.tImport, ItemsToAdd.tDate);
                flowLayoutPanel1.Controls.Add(NewPanel);
            }
        }

        private void ShowStars()
        {
            flowLayoutPanel1.Controls.Clear();
            for (int i = 0; i < Money.ListAmount(); i++)
            {
                var ItemsToAdd = Money.GetTransactionFromIndex(i);

                //This line stills compiler to skip this entity, since it isn't important
                if (!ItemsToAdd.tImport)
                    continue;

                var NewPanel = new PaymentBox(ItemsToAdd.tType, ItemsToAdd.Amount, ItemsToAdd.tName, ItemsToAdd.tImport, ItemsToAdd.tDate);
                flowLayoutPanel1.Controls.Add(NewPanel);
            }
        }

        private void checkedListBox1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            //https://stackoverflow.com/questions/10553323/checkedlistbox-allowing-only-one-item-to-be-checked
            if (e.NewValue == CheckState.Checked && checkedListBox1.CheckedItems.Count > 0)
            {
                checkedListBox1.ItemCheck -= checkedListBox1_ItemCheck;
                checkedListBox1.SetItemChecked(checkedListBox1.CheckedIndices[0], false);
                checkedListBox1.ItemCheck += checkedListBox1_ItemCheck;
            }

            //Then we refresh the list
            flowLayoutPanel1.Controls.Clear();
            try
            {
                switch (checkedListBox1.SelectedItem.ToString())
                {
                    case "Default":
                        ShowAll();
                        break;

                    case "Favourite":
                        ShowStars();
                        break;

                    default:
                        //This means is neither of these two options
                        OtherSearch();
                        break;
                }
            }
            catch (Exception)
            {
                return;
            }

            void OtherSearch()
            {
                if (checkedListBox1.SelectedItem.ToString() != null)
                {
                    var ItemsToAdd = OSort.GetPaymentsFromCategory(checkedListBox1.SelectedItem.ToString());

                    for (int i = 0; i < ItemsToAdd.Count; i++)
                    {
                        var NewPanel = new PaymentBox(ItemsToAdd[i].tType, ItemsToAdd[i].Amount, ItemsToAdd[i].tName, ItemsToAdd[i].tImport, ItemsToAdd[i].tDate);
                        flowLayoutPanel1.Controls.Add(NewPanel);
                    }
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //We get all payments into a file first.
            if (Money.ListAmount() == 0)
                MessageBox.Show("Cannot save, no payments were found");
            else
            {
                for (int i = 0; i < Money.ListAmount(); i++)
                {
                    ExtractData.AppendPayments(Money.GetTransactionFromIndex(i));
                }
            }

            //Now we get all the categorys into a file
            ExtractData.AppendCategorys();

            ExtractData.WritetoFile();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(Money.ListAmount() > 0)
            {
                DialogResult result = MessageBox.Show("You've already put in payments, Pressing Yes will Remove the current payments", "Warning",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    DoFileLoad();
                }
                
            }
            else
            {
                DoFileLoad();
            }

            void DoFileLoad()
            {
                //https://stackoverflow.com/questions/16136383/reading-a-text-file-using-openfiledialog-in-windows-forms
                OpenFileDialog theDialog = new OpenFileDialog();
                theDialog.Title = "Open Payment File (iop)";
                theDialog.Filter = "InputOutput Panel File|*.iop";
                theDialog.InitialDirectory = @"C:\";
                if (theDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        ExtractData.ZipThing(theDialog.FileName);
                        UpdateCatagoryBox();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                    }
                }

            }
        }
    }
}