﻿using System;
using System.Collections.Generic;

namespace ioPanel
{
   public class Money
    {
        public delegate void EventHandler();

        public static event EventHandler TransactionCompleted;

        private static decimal Balance { get; set; }
        private static List<Transaction> Payments = new List<Transaction>();

        #region Methods
        public static string GetBalance()
        {
            return $"Current Balance: £{Balance}";
        }

        public static decimal GetBalanceNumber()
        {
            return Balance;
        }

        public static Transaction GetTransactionFromIndex(int ind)
        {
            return Payments[ind];
        }

        public static Transaction GetTransactionInfo(string Name)
        {
            int SearchIndex = 0;
            for (int i = 0; i < Payments.Count; i++)
            {
                if (Payments[i].tName == Name)
                {
                    SearchIndex = i;
                    break;
                }
            }
            return Payments[SearchIndex];
        }

        public static void AddPayment(string traType, decimal amount, string traName, bool tImp)
        {

            var value = $"Date: {DateTime.Now.Day}/{DateTime.Now.Month}";

            var Moneyz = "";
            if (traType == "+")
            {
                Moneyz = $"+£{amount}";
            }
            else
            {
                Moneyz = $"-£{amount}";
            }

            Payments.Add(new Transaction { tType = traType, Amount = amount, tName = traName, tImport = tImp, tDate = value} );

            //Uses LINQ to find index
            int pIndex = Payments.FindIndex(a => a.tName == traName);

            if (Payments[pIndex].tHistory == null)
                Payments[pIndex].tHistory = new List<string>();

            Payments[pIndex].tHistory.Add($"{value},{Moneyz}");

            DoPayment(traType, amount);

            Program.MainForm.flowLayoutPanel1.Controls.Add(new PaymentBox(traType, amount, traName, tImp, value));
        }

        public static void InsertPayments(string[] ListOfPayments)
        {
            Payments.Clear();


            for (int i = 0; i < ListOfPayments.Length; i++)
            {
                var ItemsSplit = ListOfPayments[i].Split('`');

                var tType = ItemsSplit[0].Replace("Type:", "").Trim();
                var Name = ItemsSplit[2].Replace("Name:", "").Trim();
                var Amount = ItemsSplit[1].Replace("Amount:", "").Trim();
                var Important = ItemsSplit[3].Replace("Important:", "").Trim();
                var Date = ItemsSplit[4].Replace("DT:", "").Trim();
                var History = ItemsSplit[5].Replace("M:", "").Trim();
                var nHistory = History.Split('[');
                var hList = new List<string>();

                for (int z = 0; z < nHistory.Length; z++)
                {
                    var EditedData = nHistory[z].Replace("{", "").Replace("}", "").Replace("[", "").Replace("]", "").Replace("?", "£");

                    if (EditedData.Contains("Date: "))
                        hList.Add(EditedData);
                }

                Payments.Add(new Transaction { tType = tType, Amount = Convert.ToDecimal(Amount), tName = Name, tImport = Convert.ToBoolean(Important), tDate = Date, tHistory = hList });
                DoPayment(tType, Convert.ToDecimal(Amount));

                Program.MainForm.flowLayoutPanel1.Controls.Add(new PaymentBox(tType, Convert.ToDecimal(Amount), Name, Convert.ToBoolean(Important), Date));

            }
        }

        public static int ListAmount()
        {
            return Payments.Count;
        }

        public static List<string> GetHistory(int Index)
        {
            return Payments[Index].tHistory;
        }

        public static void UpdatePayment(int indexControl, string traType, decimal amount, string traName, bool tImp)
        {
            var value = $"Date: {DateTime.Now.Day}/{DateTime.Now.Month}";
            var Moneyz = "";
            if (traType == "+")
            {
                Moneyz = $"+£{amount}";
            }
            else
            {
                Moneyz = $"-£{amount}";
            }
            //First we make the total sum do the opposite of what payment type it is
            Transaction SubjectOfInterest = new Transaction();
            FindPayment(ref SubjectOfInterest, indexControl);

            //Making the total sum opposite of SubjectOfInterest to even it up
            DoIllegalPayment(SubjectOfInterest.tType, SubjectOfInterest.Amount);

            //Now, we apply our new amount
            DoUpdatePayment(traType, amount);

            var CarryOverHistory = Money.GetHistory(indexControl);
            //var NewData = new Transaction(traType, amount, traName, tImp);

            Money.Payments.RemoveAt(indexControl);
            Money.Payments.Insert(indexControl, new Transaction { tType = traType, Amount = amount, tName = traName, tImport = tImp, tDate = value });

            //Uses LINQ to find index
            int pIndex = Payments.FindIndex(a => a.tName == traName);

            if (Payments[pIndex].tHistory == null)
            {
                Payments[pIndex].tHistory = new List<string>();
            }
            Payments[pIndex].tHistory = CarryOverHistory;
            Payments[pIndex].tHistory.Add(($"{value},{Moneyz}"));

            UpdateControl();
            TransactionCompleted.Invoke();
        }

        private static void UpdateControl()
        {
            //Grab the last controls

            Program.MainForm.flowLayoutPanel1.Controls.Clear();
            for (int i = 0; i < Money.Payments.Count; i++)
            {
                var NewPanel = new PaymentBox(Money.Payments[i].tType, Money.Payments[i].Amount, Money.Payments[i].tName, Money.Payments[i].tImport, Money.Payments[i].tDate);
                Program.MainForm.flowLayoutPanel1.Controls.Add(NewPanel);
            }
        }

        public static string[] GetPaymentNames()
        {
            var Result = new List<string>();

            for (int i = 0; i < Payments.Count; i++)
            {
                Result.Add(Payments[i].tName);
            }
            return Result.ToArray();
        }


        public static string GetPaymentType(int Index)
        {
            return Money.Payments[Index].tType;
        }

        public static decimal GetPaymentAmount(int Index)
        {
            return Money.Payments[Index].Amount;
        }

        public static bool GetPaymentImp(int Index)
        {
            return Money.Payments[Index].tImport;
        }

        public static string GetPaymentName(int Index)
        {
            return Money.Payments[Index].tName;
        }

        private static void FindPayment(ref Transaction FoundSubject, int Index)
        {
            for (int i = 0; i < Money.Payments.Count; i++)
            {
                if (i == Index)
                    FoundSubject = Money.Payments[i];
            }
        }

        private static void DoIllegalPayment(string traType, decimal amount)
        {
            if (traType == "+") { Balance -= amount; } else { Balance += amount; }
        }

        public static void DoUpdatePayment(string traType, decimal amount)
        {
            if (traType == "+") { Balance += amount; } else { Balance -= amount; }
        }

        private static void DoPayment(string traType, decimal amount)
        {
            if (traType == "+") { Balance += amount; } else { Balance -= amount; }
            TransactionCompleted.Invoke();
        }
        #endregion
    }

    public class Transaction
    {
        public Transaction()
        {
        }

        public Transaction(string traType, decimal amount, string traName, bool tImp)
        {
            tType = traType;
            Amount = amount;
            tName = traName;
            tImport = tImp;
        }

        public Transaction(Transaction transaction)
        {
            tType = transaction.tType;
            Amount = transaction.Amount;
            tName = transaction.tName;
            tImport = transaction.tImport;
            tDate = transaction.tDate;
            tHistory = transaction.tHistory;
        }

        public class Method
        {
            public static string surplus = "+";
            public static string deficit = "-";

            public static bool GetType(string paraRef)
            {
                var Result = false;

                //We only need to check true, if not, result still remains false
                if (paraRef.ToString() == surplus)
                    Result = true;

                return Result;
            }
        }

        public string tType { get; set; }
        public decimal Amount { get; set; }
        public string tName { get; set; }
        public bool tImport { get; set; }
        public string tDate { get; set; }
        public List<string> tHistory = new List<string>();
    }
}