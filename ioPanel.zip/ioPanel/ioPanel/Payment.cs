﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ioPanel
{
    public partial class Payment : Form
    {
        private int? iastIndex = null;

        private static string tType { get; set; }
        private static decimal Amount { get; set; }
        private static string tName { get; set; }
        private static bool tImport { get; set; }

        public Payment()
        {
            InitializeComponent();
        }

        public Payment(int IndexReference)
        {
            tType = Money.GetPaymentType(IndexReference);
            Amount = Money.GetPaymentAmount(IndexReference);
            tName = Money.GetPaymentName(IndexReference);
            tImport = Money.GetPaymentImp(IndexReference);

            InitializeComponent();

            if (tType == "+")
            {
                comboBox1.Text = "Surplus";
            }
            else
            {
                comboBox1.Text = "Deficit";
            }

            textBox1.Text = Amount.ToString();

            textBox2.Text = tName;

            if (tImport)
                checkBox1.CheckState = CheckState.Checked;

            iastIndex = IndexReference;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (iastIndex == null)
                {
                    if (comboBox1.Text == "Surplus")
                    {
                        Money.AddPayment(Transaction.Method.surplus, Convert.ToDecimal(textBox1.Text), textBox2.Text, checkBox1.Checked);
                    }
                    else
                    {
                        Money.AddPayment(Transaction.Method.deficit, Convert.ToDecimal(textBox1.Text), textBox2.Text, checkBox1.Checked);
                    }
                }
                else
                {
                    //Int has been casted because we used the ? wildcard when we decleared the integer

                    if (comboBox1.Text == "Surplus")
                    {
                        Money.UpdatePayment((int)iastIndex, Transaction.Method.surplus, Convert.ToDecimal(textBox1.Text), textBox2.Text, checkBox1.Checked);
                    }
                    else
                    {
                        Money.UpdatePayment((int)iastIndex, Transaction.Method.deficit, Convert.ToDecimal(textBox1.Text), textBox2.Text, checkBox1.Checked);
                    }
                }
                this.Close();
            }
            catch (Exception)
            {

                return;
            }

        }

        private void Payment_Load(object sender, EventArgs e)
        {
            label3.Text = Money.GetBalance();


        }
    }
}
