﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HigherLower;
using BlackJack;

namespace BlackJack
{
    public partial class PlayerUI : UserControl
    {
        public int _index { get; set; }
        public string _name { get; set; }
        public BlackJackClient _info { get; set; }

        public int currentIndex = 0;

        public delegate void EventHandler();
        public EventHandler isPlaying;
        public EventHandler isNotPlaying;
        public EventHandler playComplete;

        public PlayerUI(int index, string name)
        {
            this._index = index;
            this._name = name;
            this._info = BlackJack.GetPlayerByName(name);
            InitializeComponent();
        }

        private void PlayerUI_Load(object sender, EventArgs e)
        {
            nameLabel.Text = this._name;

            isPlaying += clientPlaying;
            isNotPlaying += clientNotPlaying;
            playComplete += clientPlayDone;
            BlackJackRounds.isGameOver += clientFail;
        }

        void clientPlaying()
        {
            pictureBox1.Show();
            pictureBox1.Image = Properties.Resources.playerWait;
        }

        void clientFail()
        {
            currentIndex = 0;
            BlackJackRounds.UpdateBJC.Invoke();
            clientUpdate();
        }

        void clientNotPlaying()
        {
            clientUpdate();
            pictureBox1.Hide();
            pictureBox1.Image = null;
        }

        void clientUpdate()
        {
            if(currentIndex == 0)
            {
                pictureBox2.BackColor = Color.Maroon;
                pictureBox3.BackColor = Color.Maroon;
                pictureBox4.BackColor = Color.Maroon;
                pictureBox5.BackColor = Color.Maroon;
            }
            this.Refresh();
            this.Update();

        }

        void clientPlayDone()
        {
            currentIndex++;

            if(currentIndex == 1)
            {
                pictureBox2.BackColor = Color.Green;
                pictureBox3.BackColor = Color.Maroon;
                pictureBox4.BackColor = Color.Maroon;
                pictureBox5.BackColor = Color.Maroon;
            }
            else
            {
                if(currentIndex == 2)
                {
                    pictureBox2.BackColor = Color.Green;
                    pictureBox3.BackColor = Color.Green;
                    pictureBox4.BackColor = Color.Maroon;
                    pictureBox5.BackColor = Color.Maroon;
                }
                else
                {
                    if(currentIndex == 3)
                    {
                        pictureBox2.BackColor = Color.Green;
                        pictureBox3.BackColor = Color.Green;
                        pictureBox4.BackColor = Color.Green;
                        pictureBox5.BackColor = Color.Maroon;
                    }
                    else
                    {
                        pictureBox2.BackColor = Color.Green;
                        pictureBox3.BackColor = Color.Green;
                        pictureBox4.BackColor = Color.Green;
                        pictureBox5.BackColor = Color.Green;
                        currentIndex = 0;
                    }
                }
            }
            clientUpdate();
        }
    }
}
