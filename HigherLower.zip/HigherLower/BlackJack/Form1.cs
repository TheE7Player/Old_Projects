﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlackJack
{
    public partial class Form1 : Form
    {
        //https://stackoverflow.com/questions/13992429/adding-controls-to-tablelayoutpanel-dynamically-during-runtime

        BlackJack bj21Client = new BlackJack();
        private const int WaitDelay = 1500;

        public Form1()
        {
            InitializeComponent();
        }

        //Holds our UI to display who is current playing
        private List<PlayerUI> GUI_Client = new List<PlayerUI>();
        //TODO: Add bots and who is playing system
        private void Form1_Load(object sender, EventArgs e)
        {
            bj21Client.AddPlayer("James");
            bj21Client.AddPlayer("Steven");
            bj21Client.AddPlayer("Brain");

            GUI_Client.Add(new PlayerUI(0, "James"));
            GUI_Client.Add(new PlayerUI(1, "Steven"));
            GUI_Client.Add(new PlayerUI(2, "Brian"));

            foreach (var item in GUI_Client)
            {
               flowLayoutPanel1.Controls.Add(item);
            }

            BlackJackRounds.NextPlayer(ref GUI_Client);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        void DoWait()
        {
            var TaskWait = Task.Run(() =>
            {
                int rndNum = 0;
                for (int i = 0; i < WaitDelay; i++)
                {
                    rndNum = i;
                }
            });
            TaskWait.Wait();
        }

        int IndexTable = -1;
        int turnCount = -1;
        private void button1_Click_1(object sender, EventArgs e)
        {
            
            Bitmap ImageBack = null;
            bool? burst = null;
            IndexTable++;

            if (turnCount == -1)
            {
                tableLayoutPanel1.Controls.Clear();
                label1.Text = "0";
            }

            if ((turnCount + 1) <= 2)
            {
                turnCount++;
                bj21Client.DrawCard("James", ref ImageBack, ref label1, ref burst, turnCount);
                DoWait();
                if ((bool)burst) //Casting it to bool since its a null bool
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                    label1.Text = "Game Over";
                    DoWait();
                    IndexTable = -1;
                    turnCount = -1;
                }
                else
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                }

            }
            else
            {
                turnCount++;
                bj21Client.DrawCard("James", ref ImageBack, ref label1, ref burst, turnCount);
                DoWait();
                if ((bool)burst) //Casting it to bool since its a null bool
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                    label1.Text = "Game Over";
                    DoWait();
                    IndexTable = -1;
                    turnCount = -1;
                }
                else
                {
                    if (Convert.ToInt32(label1.Text) == 21)
                    {
                        tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                        label1.Text = "You won";
                        DoWait();
                        IndexTable = -1;
                        turnCount = -1;
                    }
                }

            }
            BlackJackRounds.NextPlayer(ref GUI_Client);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap ImageBack = null;
            bool? burst = null;
            IndexTable++;

            if (turnCount == -1)
            {
                tableLayoutPanel1.Controls.Clear();
                label1.Text = "0";
            }

            if ((turnCount + 1) <= 2)
            {
                turnCount++;
                bj21Client.DrawCard("James", ref ImageBack, ref label1, ref burst, turnCount);
                DoWait();
                if ((bool)burst) //Casting it to bool since its a null bool
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                    label1.Text = "Game Over";
                    DoWait();
                    IndexTable = -1;
                    turnCount = -1;
                }
                else
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                }

            }
            else
            {
                turnCount++;
                bj21Client.DrawCard("James", ref ImageBack, ref label1, ref burst, turnCount);
                DoWait();
                if ((bool)burst) //Casting it to bool since its a null bool
                {
                    tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                    label1.Text = "Game Over";
                    DoWait();
                    IndexTable = -1;
                    turnCount = -1;
                }
                else
                {
                    if (Convert.ToInt32(label1.Text) == 21)
                    {
                        tableLayoutPanel1.Controls.Add(new PictureBox { Image = ImageBack, SizeMode = PictureBoxSizeMode.StretchImage, Dock = DockStyle.Fill }, IndexTable, 0);
                        label1.Text = "You won";
                        DoWait();
                        IndexTable = -1;
                        turnCount = -1;
                    }
                }

            }
            BlackJackRounds.NextPlayer(ref GUI_Client);
        }
    }
}
