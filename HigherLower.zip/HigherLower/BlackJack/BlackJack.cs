﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HigherLower;
using System.Windows.Forms;
using System.Drawing;
namespace BlackJack
{
    public class BlackJack
    {
        //An dynamic list which holds our players information in a custom class! (OOP Programming)
        private static List<BlackJackClient> listofPlayers = new List<BlackJackClient>();
        /// <summary>
        /// Adds new player into the game
        /// </summary>
        /// <param name="_Name">Client's Name</param>
        public void AddPlayer(string _Name)
        {
            listofPlayers.Add(new BlackJackClient(_Name));
            BlackJackRounds.AddPerson(BlackJack.GetPlayerByName(_Name));
        }

        public void DrawCard(string _Name, ref Bitmap _returnPic, ref Label _text, ref bool? isBurst, int playCount)
        {
            //Returns true/flase if this name exists in the list.
            var DoesExist = listofPlayers.Where(i => i.Name == _Name).ToList();
            if(DoesExist.Count == 1)
            {
                int Index = GetIndex(DoesExist[0].Name);
                
                _returnPic = listofPlayers[Index].DrawCard();
                _text.Text = listofPlayers[Index].GetNumber().ToString();

                if (playCount <= 2 && (listofPlayers[Index].GetNumber() < 21))
                {
                    if (listofPlayers[Index].GetNumber() > 21)
                    {
                        isBurst = true;
                        BlackJackRounds.isGameOver.Invoke();
                        listofPlayers[Index].ResetPlayer();
                    }
                    else
                    {
                        isBurst = false;
                    }
                }
                else {
                    if(listofPlayers[Index].GetNumber() > 21 || listofPlayers[Index].GetNumber() < 21)
                    {
                        isBurst = true;
                        BlackJackRounds.isGameOver.Invoke();
                        listofPlayers[Index].ResetPlayer();
                    }
                    else
                    {
                        isBurst = false;
                        if (playCount == 4)
                        {
                            BlackJackRounds.isGameOver.Invoke();
                            listofPlayers[Index].ResetPlayer();
                        }
                    }
                    
                }
            }
            else
            {
                Console.WriteLine("No entity exists!");
            }
            
        }

        public static void CPUCard(string _Name, int playCount)
        {
            var DoesExist = listofPlayers.Where(i => i.Name == _Name).ToList();
            if (DoesExist.Count == 1)
            {
                int Index = GetIndex(DoesExist[0].Name);

                listofPlayers[Index].DrawCardNum();

                if (playCount <= 2 && (listofPlayers[Index].GetNumber() < 21))
                {
                    if (listofPlayers[Index].GetNumber() > 21)
                    {
                        BlackJackRounds.isGameOver.Invoke();
                        listofPlayers[Index].ResetPlayer();
                    }
                }
                else
                {
                    if (listofPlayers[Index].GetNumber() > 21 || listofPlayers[Index].GetNumber() < 21)
                    {
                        BlackJackRounds.isGameOver.Invoke();
                        listofPlayers[Index].ResetPlayer();
                    }
                    else
                    {
                        if (playCount == 4)
                        {
                            BlackJackRounds.isGameOver.Invoke();
                            listofPlayers[Index].ResetPlayer();
                        }
                    }

                }
            }
            else
            {
                Console.WriteLine("No entity exists!");
            }
        }

        public static int GetProperNumber(int _valuein)
        {
            int _ReturnValue = 0;
            switch (_valuein)
            {
                case 1:
                    _ReturnValue = 2;
                    break;

                case 2:
                    _ReturnValue = 3;
                    break;

                case 3:
                    _ReturnValue = 4;
                    break;

                case 4:
                    _ReturnValue = 5;
                    break;

                case 5:
                    _ReturnValue = 6;
                    break;

                case 6:
                    _ReturnValue = 7;
                    break;

                case 7:
                    _ReturnValue = 8;
                    break;

                case 8:
                    _ReturnValue = 9;
                    break;
                default:
                    if(_valuein >= 9)
                    {
                        _ReturnValue = 10;
                    }

                    break;
            }
            return _ReturnValue;
        }

        private static int GetIndex(string _Name)
        {
            int Index = 0;
            for (Index = 0; Index < listofPlayers.Count; Index++)
            {
                if (listofPlayers[Index].Name == _Name)
                    break;
            }
            return Index;
        }

        public List<BlackJackClient> GetListOfPlayers()
        {
            return listofPlayers;
        }

        public static BlackJackClient GetPlayerByName(string _Name)
        {
            try
            {
                var _data = listofPlayers.Where(i => i.Name == _Name).ToList();
                return _data[0];
            }
            catch (Exception)
            {

               return null;
            }           
        }

   
    }

    public class BlackJackClient
    {
        private Random rnd = new Random();

        //Holds name of the player
        public string Name { get;}

        //Holds the cards the player has
        private List<CardData> listOfCards { get; set; }

        //Holds the number of cards (If < 21 or > 21, Game over)
        private int CardNumber { get; set; }

        public int listofcardNumber(int _index)
        {
            int Result = 0;
            for (int i = 0; i < listOfCards.Count; i++)
            {
                Result += listOfCards[i].GetNumber();
            }
            return Result;
        }

        public int GetNumber()
        {
            return CardNumber;
        }

        /// <summary>
        /// Adds a new player into the game
        /// </summary>
        /// <param name="_name">The name of the client</param>
        public BlackJackClient(string _name)
        {
            //Assigns name to the player
            this.Name = _name;

            //Checks if listofCards is empty, if so init the list
            if (listOfCards == null)
                listOfCards = new List<CardData>();
            
            //Assigns it to default number (Everyone starts at zero)
            CardNumber = 0;
        }

        public BlackJackClient(BlackJackClient _self)
        {
            //Assigns name to the player
            this.Name = _self.Name;

            //Checks if listofCards is empty, if so init the list
            this.listOfCards = _self.listOfCards;

            //Assigns it to default number (Everyone starts at zero)
            this.CardNumber = _self.CardNumber;
        }

        public void ResetPlayer()
        {

            listOfCards = new List<CardData>();

            //Assigns it to default number (Everyone starts at zero)
            CardNumber = 0;
        }

        public Bitmap DrawCard()
        {
            var NewCard = new CardData(rnd.Next(1, 13));
            listOfCards.Add(new CardData(NewCard));
            this.CardNumber += BlackJack.GetProperNumber(NewCard.GetNumber());
            return NewCard.GetPicture(); 
        }

        public void DrawCardNum()
        {
            var NewCard = new CardData(rnd.Next(1, 13));
            listOfCards.Add(new CardData(NewCard));
            this.CardNumber += BlackJack.GetProperNumber(NewCard.GetNumber());
        }
    }

    public class BlackJackRounds
    {
        private static int PlayCount = 0;

        public delegate void EventHandler();
        public static EventHandler isGameOver;
        public static EventHandler UpdateBJC;

        private static int CurrentIndex = -1;
        private static int MaxIndex = 0;
        private static int LastPlayIndex = -1;

        private static List<BlackJackClient> _clientRounds = new List<BlackJackClient>();

        public static void AddPerson(BlackJackClient _data)
        {
            _clientRounds.Add(new BlackJackClient(_data));
        }

        //This method is executed when game over...
        static void GG()
        {
            string winnerName = string.Empty;
            int winnerNumber = 0;
            PlayCount = 0;
            for (int i = 0; i < _clientRounds.Count; i++)
            {
                if (_clientRounds[i].listofcardNumber(i) > 21)
                    continue;

                if (winnerNumber < _clientRounds[i].listofcardNumber(i))
                {
                    winnerNumber = _clientRounds[i].listofcardNumber(i);
                    winnerName = _clientRounds[i].Name;
                }
            }
            MessageBox.Show($"The winner is {winnerName} with a total of {winnerNumber}!");
        }

        public static void BotIsPlaying(ref List<PlayerUI> guiUpdate)
        {
            for (int i = 1; i < guiUpdate.Count; i++)
            {
                guiUpdate[i].isPlaying();
                System.Threading.Thread.Sleep(new Random().Next(1000, 3000));
                BlackJack.CPUCard(guiUpdate[i]._name, guiUpdate[i].currentIndex);
                guiUpdate[i].playComplete();
                guiUpdate[i].isNotPlaying();
                System.Threading.Thread.Sleep(new Random().Next(1000, 3000));
            }
        }

        public static void NextPlayer(ref List<PlayerUI> guiUpdate)
        {
            PlayCount++;
            if (PlayCount != 1)
            {
                if (UpdateBJC == null)
                    UpdateBJC += GG;

                if (MaxIndex == 0)
                    MaxIndex = guiUpdate.Count;

                if (LastPlayIndex == CurrentIndex)
                {
                    guiUpdate[LastPlayIndex].playComplete.Invoke();
                    guiUpdate[LastPlayIndex].isNotPlaying.Invoke();
                }

                if ((CurrentIndex + 1) <= MaxIndex - 1)
                {
                    CurrentIndex++;
                }
                else
                {
                    CurrentIndex = 0;
                }
            }

            for (int i = 0; i < _clientRounds.Count; i++)
            {
                if(i == CurrentIndex)
                {
                    guiUpdate[i].isPlaying.Invoke();
                    LastPlayIndex = i;
                }
                else
                {
                    if(CurrentIndex == -1 && LastPlayIndex == -1)
                    {
                        guiUpdate[0].isPlaying.Invoke();
                        LastPlayIndex = 0;
                        CurrentIndex = 0;
                    }
                    else
                    {
                        guiUpdate[i].isNotPlaying.Invoke();
                    }
                }
            }

            if (PlayCount > 1)
                BotIsPlaying(ref guiUpdate);
        }
    }
}
