﻿using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HigherLower
{
    public partial class Form1 : Form
    {
        private Random rnd = new Random();

        private int Wins = 0, loss = 0;
        private int CardOfChoice = 1;
        
        private CardData[] LastCard;

        public Form1()
        {
            InitializeComponent();
            NewCards();
        }

        private void NewCards()
        {
            //Set all the cards to back of the deck
            pictureBox2.Image = HigherLower.Properties.Resources.Red_Back;
            pictureBox3.Image = HigherLower.Properties.Resources.Red_Back;
            pictureBox4.Image = HigherLower.Properties.Resources.Red_Back;
            pictureBox5.Image = HigherLower.Properties.Resources.Red_Back;
            pictureBox6.Image = HigherLower.Properties.Resources.Red_Back;

            LastCard = new CardData[6];
            for (int i = 0; i < LastCard.Length; i++)
            {
                LastCard[i] = new CardData(rnd.Next(1, 13));
                if (i == 0) { pictureBox1.Image = LastCard[i].GetPicture(); }
                // Console.WriteLine($"{LastCard[i].GetNumber()}");
            }
        }

        private Bitmap QuestionCard = HigherLower.Properties.Resources.selected_card;

        private void AskQuestion()
        {
            this.Update();
            label2.Text = Wins.ToString();
            label3.Text = loss.ToString();
            label1.Text = $"Is Card {CardOfChoice + 1} Higher or lower?";
            switch (CardOfChoice)
            {
                case 1:
                    pictureBox2.Image = QuestionCard;
                    break;

                case 2:
                    DoJump(ref pictureBox2, false);
                    pictureBox2.Image = LastCard[1].GetPicture();
                    pictureBox3.Image = QuestionCard;
                    DoJump(ref pictureBox2, true);
                    break;

                case 3:
                    DoJump(ref pictureBox3, false);
                    pictureBox3.Image = LastCard[2].GetPicture();
                    pictureBox4.Image = QuestionCard;
                    DoJump(ref pictureBox3, true);
                    break;

                case 4:
                    DoJump(ref pictureBox4, false);
                    pictureBox4.Image = LastCard[3].GetPicture();
                    pictureBox5.Image = QuestionCard;
                    DoJump(ref pictureBox4, true);
                    break;

                case 5:
                    DoJump(ref pictureBox5, false);
                    pictureBox5.Image = LastCard[4].GetPicture();
                    pictureBox6.Image = QuestionCard;
                    DoJump(ref pictureBox5, true);
                    break;

                case 6:
                    DoJump(ref pictureBox6, false);
                    pictureBox6.Image = LastCard[5].GetPicture();
                    DoJump(ref pictureBox6, true);
                    break;

                default:
                    break;
            }
            CardOfChoice++;
        }

        private void DoJump(ref PictureBox pic, bool back)
        {
            PictureBox.CheckForIllegalCrossThreadCalls = false;
            if (!back)
            {
                var newHeight = pic.Location.Y - 20;
                for (int i = pic.Location.Y; i > newHeight; i--)
                {
                    pic.Location = new Point(pic.Location.X, i);
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(2);
                }
            }
            else
            {
                var newHeight = pic.Location.Y + 20;
                for (int i = pic.Location.Y; i < newHeight; i++)
                {
                    pic.Location = new Point(pic.Location.X, i);
                    Application.DoEvents();
                    System.Threading.Thread.Sleep(2);
                }
            }
        }

        private void CheckAnswer(bool answer)
        {
            var SimpTask = Task.Run(() =>
            {
                int index1 = CardOfChoice - 2;

                //We check if it works
                if ((CardOfChoice - 2) < 0) { index1++; }
                int index2 = index1 + 1;

                try
                {
                    int card1 = LastCard[index1].GetNumber(), card2 = LastCard[index2].GetNumber();
                    var Validate = (card2 > card1) ? true : false;

                    if (answer == Validate)
                    {
                        if (index2 == 5 && answer == Validate)
                        {
                            var t = Task.Run(() =>
                            {
                                SoundEngine.PlaySound(SoundEngine.Sounds.Win);
                                DoJump(ref pictureBox6, false);
                                pictureBox6.Image = LastCard[LastCard.Length - 1].GetPicture();
                                DoJump(ref pictureBox6, true);
                            });
                            t.Wait();

                            DoJump(ref pictureBox7, false);
                            Wins++;
                            DoJump(ref pictureBox7, true);

                            CardOfChoice = 1; //Cannot be 1, 1 - 2 = -1 (No -1 in array)
                            NewCards();
                            AskQuestion();
                            player.DoMethod(Player.DoMove.win, 150);
                        }
                        else
                        {
                            SoundEngine.PlaySound(SoundEngine.Sounds.Correct);
                            AskQuestion();
                            player.DoMethod(Player.DoMove.win, 2);
                        }
                    }
                    else
                    {
                        var t = Task.Run(() =>
                        {
                            SoundEngine.PlaySound(SoundEngine.Sounds.Loss);
                            DoJump(ref pictureBox8, false);
                            loss++;
                            DoJump(ref pictureBox8, true);
                        });
                        t.Wait();
                        player.DoMethod(Player.DoMove.lose, 60);
                        CardOfChoice = 1; //Cannot be 1, 1 - 2 = -1 (No -1 in array)
                        NewCards();
                        AskQuestion();
                    }
                }
                catch (Exception)
                {
                    if (index2 > 5)
                    {
                        index2 = 5;
                    }
                    int card1 = LastCard[index1].GetNumber(), card2 = LastCard[index2].GetNumber();

                    var Validate = (card2 >= card1) ? true : false;

                    if (answer == Validate)
                    {
                        if (index2 == 5 && answer == Validate)
                        {
                            var t = Task.Run(() =>
                            {
                                SoundEngine.PlaySound(SoundEngine.Sounds.Win);
                                DoJump(ref pictureBox6, false);
                                pictureBox6.Image = LastCard[LastCard.Length - 1].GetPicture();
                                DoJump(ref pictureBox6, true);
                            });
                            t.Wait();

                            DoJump(ref pictureBox7, false);
                            Wins++;
                            DoJump(ref pictureBox7, true);

                            player.DoMethod(Player.DoMove.win, 150);
                            CardOfChoice = 1; //Cannot be 1, 1 - 2 = -1 (No -1 in array)
                            NewCards();
                            AskQuestion();
                        }
                        else
                        {
                            SoundEngine.PlaySound(SoundEngine.Sounds.Correct);
                            AskQuestion();
                            player.DoMethod(Player.DoMove.win, 2);
                        }
                    }
                    else
                    {
                        var t = Task.Run(() =>
                        {
                            SoundEngine.PlaySound(SoundEngine.Sounds.Loss);
                            DoJump(ref pictureBox8, false);
                            loss++;
                            DoJump(ref pictureBox8, true);
                        });
                        t.Wait();
                        player.DoMethod(Player.DoMove.lose, 60);
                        CardOfChoice = 1; //Cannot be 1, 1 - 2 = -1 (No -1 in array)
                        NewCards();
                        AskQuestion();
                    }
                }
            });
            SimpTask.Wait();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Higher button
            CheckAnswer(true);
        }

        private Player player = new Player();

        private void Form1_Load(object sender, EventArgs e)
        {
            //Allows us to access the form while using Task.Run
            Form.CheckForIllegalCrossThreadCalls = false;

            this.DoubleBuffered = true;
            AskQuestion();
            label4.Text = player.GetAmount();
            player.DoMoneyUpdate += new Player.EventHandler(UpdateText);
            player.NoMoney += new Player.EventHandler(GG);
            player.DoPress += new Player.EventHandler(Wait);
            this.ActiveControl = null;
        }

        private void Wait()
        {
            var TaskWait = Task.Run(() =>
            {
                player.DoWait();
            });
            TaskWait.Wait();
        }

        private void GG()
        {
            MessageBox.Show("Game over, no money left!");
            Wins = 0;
            loss = Wins;
        }

        private void UpdateText()
        {
            label4.Text = player.GetAmount();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.H:
                    CheckAnswer(true);
                    break;

                case Keys.L:
                    CheckAnswer(false);
                    break;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //lower button
            CheckAnswer(false);
        }
    }
}