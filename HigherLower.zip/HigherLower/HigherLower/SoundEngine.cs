﻿using System.IO;
using System.Media;

namespace HigherLower
{
    internal class SoundEngine
    {

        public enum Sounds
        {
            Win,
            Loss,
            Correct
        }

        public static void PlaySound(Sounds sndName)
        {
            
            switch (sndName)
            {
                case Sounds.Win:
                    new System.Media.SoundPlayer(Properties.Resources.win).Play();
                    break;

                case Sounds.Loss:
                    new System.Media.SoundPlayer(Properties.Resources.wrong1).Play();
                    break;

                case Sounds.Correct:
                    new System.Media.SoundPlayer(Properties.Resources.correct).Play();
                    break;

                default:
                    break;
            }

        }
    }
}