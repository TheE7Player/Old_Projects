﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace HigherLower
{
    public enum CardParents
    {
        clubs,
        hearts,
        spades,
        diamonds
    }

    public enum CardTypes
    {
        two = 1,
        three = 2,
        four = 3,
        five = 4,
        six = 5,
        seven = 6,
        eight = 7,
        nine = 8,
        ten = 9,
        king = 12,
        queen = 11,
        jack = 10,
        ace = 13
    }

    public static class Cards
    {
        public static void Spades(int Num, ref Bitmap ReturnPic)
        {
            switch (Num)
            {
                case 1:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._2_of_spades);
                    break;

                case 2:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._3_of_spades);
                    break;

                case 3:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._4_of_spades);
                    break;

                case 4:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._5_of_spades);
                    break;

                case 5:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._6_of_spades);
                    break;

                case 6:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._7_of_spades);
                    break;

                case 7:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._8_of_spades);
                    break;

                case 8:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._9_of_spades);
                    break;

                case 9:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._10_of_spades);
                    break;

                case 10:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.jack_of_spades);
                    break;

                case 11:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.queen_of_spades);
                    break;

                case 12:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.king_of_spades);
                    break;

                case 13:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.ace_of_spades);
                    break;
                default:
                    break;
            }
        }

        public static void Hearts(int Num, ref Bitmap ReturnPic)
        {
            switch (Num)
            {
                case 1:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._2_of_hearts);
                    break;

                case 2:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._3_of_hearts);
                    break;

                case 3:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._4_of_hearts);
                    break;

                case 4:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._5_of_hearts);
                    break;

                case 5:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._6_of_hearts);
                    break;

                case 6:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._7_of_hearts);
                    break;

                case 7:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._8_of_hearts);
                    break;

                case 8:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._9_of_hearts);
                    break;

                case 9:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._10_of_hearts);
                    break;

                case 10:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.jack_of_hearts);
                    break;

                case 11:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.queen_of_hearts);
                    break;

                case 12:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.king_of_hearts);
                    break;

                case 13:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.ace_of_hearts);
                    break;
                default:
                    break;
            }
        }

        public static void Diamonds(int Num, ref Bitmap ReturnPic)
        {
            switch (Num)
            {
                case 1:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._2_of_diamonds);
                    break;

                case 2:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._3_of_diamonds);
                    break;

                case 3:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._4_of_diamonds);
                    break;

                case 4:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._5_of_diamonds);
                    break;

                case 5:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._6_of_diamonds);
                    break;

                case 6:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._7_of_diamonds);
                    break;

                case 7:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._8_of_diamonds);
                    break;

                case 8:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._9_of_diamonds);
                    break;

                case 9:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._10_of_diamonds);
                    break;

                case 10:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.jack_of_diamonds);
                    break;

                case 11:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.queen_of_diamonds);
                    break;

                case 12:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.king_of_diamonds);
                    break;

                case 13:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.ace_of_diamonds);
                    break;
                default:
                    break;
            }
        }

        public static void Clubs(int Num, ref Bitmap ReturnPic)
        {
            switch (Num)
            {
                case 1:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._2_of_clubs);
                    break;

                case 2:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._3_of_clubs);
                    break;

                case 3:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._4_of_clubs);
                    break;

                case 4:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._5_of_clubs);
                    break;

                case 5:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._6_of_clubs);
                    break;

                case 6:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._7_of_clubs);
                    break;

                case 7:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._8_of_clubs);
                    break;

                case 8:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._9_of_clubs);
                    break;

                case 9:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources._10_of_clubs);
                    break;

                case 10:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.jack_of_clubs);
                    break;

                case 11:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.queen_of_clubs);
                    break;

                case 12:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.king_of_clubs);
                    break;

                case 13:
                    ReturnPic = new Bitmap(HigherLower.Properties.Resources.ace_of_clubs);
                    break;
                default:
                    break;
            }
        }
    }

    public class CardData
    {
        Random rnd = new Random();

        //To-Do: Do validation from here!
        Bitmap cardPicture { get; set; }
        int CardNumber { get; set; }

        public CardData(int CardNumber)
        {
            //1 = 2 , 13 = Ace
            if(CardNumber >= 1 && CardNumber <= 13)
            {
                //Good, we are in range.
                this.CardNumber = CardNumber;

                //Now we get the bitmap assigned
                Bitmap bitRef = null;
                switch (RandomParent())
                {
                    case CardParents.clubs:
                        Cards.Clubs(CardNumber, ref bitRef);
                        this.cardPicture = bitRef;
                        break;
                    case CardParents.hearts:
                        Cards.Hearts(CardNumber, ref bitRef);
                        this.cardPicture = bitRef;
                        break;
                    case CardParents.spades:
                        Cards.Spades(CardNumber, ref bitRef);
                        this.cardPicture = bitRef;
                        break;
                    case CardParents.diamonds:
                        Cards.Diamonds(CardNumber, ref bitRef);
                        this.cardPicture = bitRef;
                        break;
                    default:
                        break;
                }
            }
        }

        public CardData(CardData _card)
        {
            this.CardNumber = _card.CardNumber;
            this.cardPicture = _card.cardPicture;
        }

        public Bitmap GetPicture()
        {
            return this.cardPicture;
        }
       
        public int GetNumber()
        {
            return CardNumber;
        }

        private CardParents RandomParent()
        {
            var Return = CardParents.clubs; //Assign it automatically
        
            switch (rnd.Next(0, 3)) //Picks number between 0 and 4 (0 to 3)
            {
                case 1:
                    Return = CardParents.diamonds;
                    break;

                case 2:
                    Return = CardParents.hearts;
                    break;

                case 3:
                    Return = CardParents.spades;
                    break;

                default:
                    break;
            }
            return Return;

        }
    }

    
}
