﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HigherLower
{
    internal class Player
    {
        private const int StartMoney = 800; //Compiler const. Meaning cannot be changed at all. (Fixed Value)

        public delegate void EventHandler();

        public EventHandler DoMoneyUpdate;
        public EventHandler NoMoney;
        public EventHandler DoPress;

        //Our players current money, invisable to the coder
        private int CurrentMoney { get; set; }

        public Player()
        {
            //Assigns player with startmoney value
            CurrentMoney = StartMoney;
        }

        public string GetAmount()
        {
            return $"{CurrentMoney}";
        }

        private void Sleep()
        {
            //This tells the cpu to sleep for 15ms and catch up with events
            //This makes the smooth animation of the coins text counting down.
            System.Threading.Thread.Sleep(15);
            Application.DoEvents();
        }

        public enum DoMove
        {
            win,
            lose
        }

        private Task _thread;
        private Object ThreadLock = new object();
        private bool StopMidThread = false;
        private int ThreadCount = 0;

        public void DoMethod(DoMove state, int amount)
        {
            switch (state)
            {
                case DoMove.win:
                    _thread = Task.Factory.StartNew(() => WinMoney(amount));
                    break;

                case DoMove.lose:

                    _thread = Task.Factory.StartNew(() => LoseMoney(amount));

                    break;

                default:
                    break;
            }
        }

        public void DoWait()
        {
            var waitThrad = new Thread(() =>
            {
                while (true)
                {
                    if (ThreadCount == 0)
                        break;
                }
            });
            waitThrad.Start();
        }

        private void WinMoney(int amount)
        {

            lock (ThreadLock)
            {
                int NewValue = this.CurrentMoney + amount;
                while (!StopMidThread)
                {
                    for (int i = this.CurrentMoney; this.CurrentMoney < NewValue; i++)
                    {
                        if (i > 0 && !StopMidThread)
                        {
                            this.CurrentMoney = i;
                            DoMoneyUpdate.Invoke();
                            Sleep();
                        }
                    }
                    ThreadCount--;
                    break;
                }
            }
        }

        private void LoseMoney(int amount)
        {
            lock (ThreadLock)
            {
                int NewValue = this.CurrentMoney - amount;

                if (NewValue < 0)
                {
                    CurrentMoney = 0;
                    DoMoneyUpdate.Invoke();
                    StopMidThread = false;
                    NoMoney.Invoke();
                    CurrentMoney = 800;
                    DoMoneyUpdate.Invoke();
                }
                else
                {
                    while (!StopMidThread)
                    {
                        for (int i = this.CurrentMoney; this.CurrentMoney > NewValue; i--)
                        {
                            this.CurrentMoney = i;
                            DoMoneyUpdate.Invoke();
                            Sleep();
                        }

                        break;
                    }
                }
            }
            ThreadCount--;
        }
    }
}